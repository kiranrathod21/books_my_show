import react from "react";

function temp() {
  return <h1>temp</h1>;
}
export default temp;
